INSERT INTO `ciudades` VALUES (8, "Castellon", "Comunidad Valenciana");
INSERT INTO `ciudades` VALUES (9, "Valencia", "Comunidad Valenciana");
INSERT INTO `ciudades` VALUES (10, "Alicante", "Comunidad Valenciana");
CREATE TABLE foo(
    id INT NOT NULL PRIMARY KEY,
    msj VARCHAR(32),
    bar INT);

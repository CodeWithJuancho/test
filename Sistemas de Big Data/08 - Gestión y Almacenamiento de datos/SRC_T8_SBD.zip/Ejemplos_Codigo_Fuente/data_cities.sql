INSERT INTO `ciudades` VALUES (1, "Ciudad Real", "Castilla la Mancha");
INSERT INTO `ciudades` VALUES (2, "Toledo", "Castilla la Mancha");
INSERT INTO `ciudades` VALUES (3, "Cuenca", "Castilla la Mancha");
INSERT INTO `ciudades` VALUES (4, "Albacete", "Castilla la Mancha");
INSERT INTO `ciudades` VALUES (5, "Gudalajara", "Castilla la Mancha");
INSERT INTO `ciudades` VALUES (6, "Caceres", "Extremadura");
INSERT INTO `ciudades` VALUES (7, "Badajoz", "Extremadura");
CREATE TABLE `ciudades` (
`id` INTEGER UNSIGNED NOT NULL,
`ciudad` VARCHAR(50),
`region` VARCHAR(150),
PRIMARY KEY (`id`)
);